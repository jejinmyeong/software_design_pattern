package hansung.designpatterns.observer;

public interface DisplayElement {
	public void display();
}
