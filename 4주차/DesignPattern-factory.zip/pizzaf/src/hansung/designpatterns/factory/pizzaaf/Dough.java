package hansung.designpatterns.factory.pizzaaf;


public interface Dough {
	public String toString();
}
