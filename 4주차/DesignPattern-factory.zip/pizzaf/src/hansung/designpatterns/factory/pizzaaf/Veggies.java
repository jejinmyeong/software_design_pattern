package hansung.designpatterns.factory.pizzaaf;


public interface Veggies {
	public String toString();
}
