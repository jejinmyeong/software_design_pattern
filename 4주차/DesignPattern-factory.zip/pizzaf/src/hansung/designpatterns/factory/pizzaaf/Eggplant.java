package hansung.designpatterns.factory.pizzaaf;


public class Eggplant implements Veggies {

	public String toString() {
		return "Eggplant";
	}
}
