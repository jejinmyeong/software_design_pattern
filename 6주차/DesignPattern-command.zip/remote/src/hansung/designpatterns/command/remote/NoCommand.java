package hansung.designpatterns.command.remote;

public class NoCommand implements Command {
	public void execute() { }
}
